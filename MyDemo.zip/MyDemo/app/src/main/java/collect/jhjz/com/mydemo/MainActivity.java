package collect.jhjz.com.mydemo;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;
import androidx.appcompat.app.AppCompatActivity;
import collect.jhjz.com.home.HomeFragment;
import collect.jhjz.com.hotnews.HotNewsFragment;
import collect.jhjz.com.mine.MineFragment;
import collect.jhjz.com.video.VideoFragment;

public class MainActivity extends AppCompatActivity {

    private HotNewsFragment hotNewsFragment;
    private HomeFragment homeFragment;
    private VideoFragment videoFragment;
    private MineFragment mineFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setDefaultFragment();
        BottomNavigationBar bottomNavigationBar =  findViewById(R.id.bottom_navigation_bar);

        bottomNavigationBar
                .addItem(new BottomNavigationItem(R.drawable.ic_launcher_background, "Home"))
                .addItem(new BottomNavigationItem(R.drawable.ic_launcher_background, "Books"))
                .addItem(new BottomNavigationItem(R.drawable.ic_launcher_background, "Music"))
                .addItem(new BottomNavigationItem(R.drawable.ic_launcher_background, "Movies & TV"))
                .initialise();
        bottomNavigationBar.setTabSelectedListener(new BottomNavigationBar.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position) {
                onTabSelected(position);
            }

            @Override
            public void onTabUnselected(int position) {
            }

            @Override
            public void onTabReselected(int position) {
            }
        });
    }

    /**
     * 设置默认的
     */
    private void setDefaultFragment() {
        FragmentManager fm = getFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();
        homeFragment = homeFragment.newInstance();
        transaction.replace(R.id.frame_layout,homeFragment);
        transaction.commit();
    }


    public void onTabSelected(int position) {

        FragmentManager fm = this.getFragmentManager();
        //开启事务
        FragmentTransaction transaction = fm.beginTransaction();
        switch (position) {
            case 0:
                if (homeFragment == null) {
                    homeFragment = HomeFragment.newInstance();
                }
                transaction.replace(R.id.frame_layout, homeFragment);
                break;
            case 1:
                if (hotNewsFragment == null) {
                    hotNewsFragment = HotNewsFragment.newInstance();
                }
                transaction.replace(R.id.frame_layout, hotNewsFragment);
                break;
            case 2:
                if (videoFragment == null) {
                    videoFragment = VideoFragment.newInstance();
                }
                transaction.replace(R.id.frame_layout, videoFragment);
                break;
            case 3:
                if (mineFragment == null) {
                    mineFragment = MineFragment.newInstance();
                }
                transaction.replace(R.id.frame_layout, mineFragment);
                break;
            default:
                break;
        }
        // 事务提交
        transaction.commit();
    }

}
